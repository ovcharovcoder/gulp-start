const gulp = require('gulp');
const config = require('./config');
const browserSync = require('browser-sync');

function createTasks(mode) {
  const { dir, isProd, sourceMaps } = config[mode];

  return {
    clean: require('./tasks/clean')(dir),
    html: require('./tasks/html')(dir, isProd),
    styles: require('./tasks/styles')(dir, isProd, sourceMaps.css),
    scripts: require('./tasks/scripts')(dir, isProd, sourceMaps.js),
    images: require('./tasks/images')(dir, isProd),
    svg: require('./tasks/svg')(dir, isProd),
    files: require('./tasks/files')(dir),
    fonts: require('./tasks/fonts')('./src', `./${dir}`, isProd),
    server: require('./tasks/server')(dir, config[mode].serverPort),
  };
}

const devTasks = createTasks('dev');

gulp.task('clean:dev', devTasks.clean);
gulp.task('fonts:dev', devTasks.fonts);
gulp.task('html:dev', devTasks.html);
gulp.task('styles:dev', devTasks.styles);
gulp.task('scripts:dev', devTasks.scripts);
gulp.task('images:dev', devTasks.images);
gulp.task('svg:dev', devTasks.svg);
gulp.task('files:dev', devTasks.files);
gulp.task('server:dev', devTasks.server);

const prodTasks = createTasks('prod');

gulp.task('clean:prod', prodTasks.clean);
gulp.task('fonts:prod', prodTasks.fonts);
gulp.task('html:prod', prodTasks.html);
gulp.task('styles:prod', prodTasks.styles);
gulp.task('scripts:prod', prodTasks.scripts);
gulp.task('images:prod', prodTasks.images);
gulp.task('svg:prod', prodTasks.svg);
gulp.task('files:prod', prodTasks.files);
gulp.task('server:prod', prodTasks.server);

// Watch з примусовим reload
gulp.task('watch:dev', function (done) {
  let reloading = false;

  const triggerReload = () => {
    if (!reloading) {
      reloading = true;
      setTimeout(() => {
        browserSync.reload();
        console.log('🔄 Page reloaded');
        reloading = false;
      }, 100);
    }
  };

  gulp
    .watch('./src/scss/**/*.scss', gulp.parallel('styles:dev'))
    .on('change', () => {
      setTimeout(() => browserSync.reload(), 50);
    });

  gulp
    .watch('./src/html/**/*.html', gulp.series('html:dev'))
    .on('change', () => {
      triggerReload();
    });

  gulp
    .watch('./src/js/**/*.js', gulp.parallel('scripts:dev'))
    .on('change', () => {
      triggerReload();
    });

  gulp
    .watch('./src/img/**/*.{jpg,jpeg,png}', gulp.parallel('images:dev'))
    .on('change', () => {
      triggerReload();
    });

  gulp
    .watch('./src/img/svgicons/*', gulp.series('svg:dev'))
    .on('change', () => {
      triggerReload();
    });

  gulp
    .watch('./src/files/**/*', gulp.parallel('files:dev'))
    .on('change', () => {
      triggerReload();
    });

  gulp
    .watch('./src/fonts/**/*.{otf,ttf}', gulp.series('fonts:dev', 'styles:dev'))
    .on('change', () => {
      triggerReload();
    });

  done();
});

gulp.task(
  'dev',
  gulp.series(
    'clean:dev',
    gulp.parallel('fonts:dev', 'svg:dev'),
    gulp.parallel(
      'html:dev',
      'styles:dev',
      'scripts:dev',
      'images:dev',
      'files:dev',
    ),
    gulp.parallel('server:dev', 'watch:dev'),
  ),
);

gulp.task(
  'build',
  gulp.series(
    'clean:prod',
    gulp.parallel('fonts:prod', 'svg:prod'),
    gulp.parallel(
      'html:prod',
      'styles:prod',
      'scripts:prod',
      'images:prod',
      'files:prod',
    ),
  ),
);

gulp.task('default', gulp.series('dev'));
