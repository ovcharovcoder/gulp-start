// Централізовані налаштування збірки

module.exports = {
  // Режим розробки
  dev: {
    dir: 'dist',
    serverPort: 8000,
    isProd: false,
    sourceMaps: {
      css: true,
      js: true,
    },
  },

  // Режим продакшен
  prod: {
    dir: 'dist',
    serverPort: 8001,
    isProd: true,
    sourceMaps: {
      css: false,
      js: false,
    },
  },

  // Налаштування конвертації зображень
  images: {
    webp: {
      quality: 85,
      enabled: true,
    },
    avif: {
      quality: 70,
      enabled: true,
    },
    keepOriginal: false,
  },

  // Шляхи до файлів
  paths: {
    src: {
      root: './src',
      html: './src/html/pages/**/*.html',
      scss: './src/scss/main.scss',
      js: './src/js/*.js',
      images: ['./src/img/**/*', '!./src/img/svgicons/**/*'],
      svgIcons: './src/img/svgicons/**/*.svg',
      files: './src/files/**/*',
      fonts: './src/fonts/**/*',
    },
  },

  // Налаштування плагінів
  plugins: {
    fileInclude: {
      prefix: '@@',
      basepath: './src/html/', // ← ВАЖЛИВО: базова папка для include
    },
    svgSprite: {
      mode: {
        symbol: {
          sprite: '../sprite.symbol.svg',
        },
      },
      shape: {
        transform: [
          {
            svgo: {
              js2svg: { indent: 4, pretty: true },
              plugins: [
                {
                  name: 'removeAttrs',
                  params: { attrs: '(fill|stroke)' },
                },
              ],
            },
          },
        ],
      },
    },
  },
};
