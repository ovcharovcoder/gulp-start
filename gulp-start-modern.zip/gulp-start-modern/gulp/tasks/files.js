const gulp = require('gulp');
const plumber = require('gulp-plumber');
const notify = require('gulp-notify');
const browserSync = require('browser-sync').create();
const config = require('../config');

module.exports = dir => {
  return function files() {
    return gulp
      .src(config.paths.src.files)
      .pipe(
        plumber(
          notify.onError({
            title: 'Files',
            message: 'Error: <%= error.message %>',
          }),
        ),
      )
      .pipe(gulp.dest(`./${dir}/files/`))
      .pipe(browserSync.reload({ stream: true }));
  };
};
