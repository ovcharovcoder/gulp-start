const gulp = require('gulp');
const fonter = require('gulp-fonter-fix');
const ttf2woff2 = require('gulp-ttf2woff2');
const fs = require('fs');
const path = require('path');
const plumber = require('gulp-plumber');
const notify = require('gulp-notify');
const browserSync = require('browser-sync').create();

module.exports = (srcDir, destDir, isProd) => {
  return async function fonts() {
    console.log('🔄 Конвертація шрифтів...');

    if (!fs.existsSync(`${srcDir}/fonts/`)) {
      console.log('⚠️ Папка з шрифтами не знайдена');
      return;
    }

    // Конвертація OTF → TTF
    const otfFiles = fs
      .readdirSync(`${srcDir}/fonts/`)
      .filter(f => f.endsWith('.otf'));

    for (const file of otfFiles) {
      console.log(`📦 Конвертація: ${file}`);
      await new Promise((resolve, reject) => {
        gulp
          .src(`${srcDir}/fonts/${file}`)
          .pipe(
            plumber(
              notify.onError({
                title: 'Fonts (OTF→TTF)',
                message: 'Error: <%= error.message %>',
              }),
            ),
          )
          .pipe(fonter({ formats: ['ttf'] }))
          .pipe(gulp.dest(`${srcDir}/fonts/`))
          .on('end', resolve)
          .on('error', reject);
      });
    }

    // Конвертація TTF → WOFF та WOFF2
    const ttfFiles = fs
      .readdirSync(`${srcDir}/fonts/`)
      .filter(f => f.endsWith('.ttf'));

    if (ttfFiles.length === 0) {
      console.log('⚠️ Немає TTF файлів для конвертації');
      return;
    }

    for (const file of ttfFiles) {
      await new Promise((resolve, reject) => {
        gulp
          .src(`${srcDir}/fonts/${file}`)
          .pipe(
            plumber(
              notify.onError({
                title: 'Fonts (TTF→WOFF)',
                message: 'Error: <%= error.message %>',
              }),
            ),
          )
          .pipe(fonter({ formats: ['woff'] }))
          .pipe(gulp.dest(`${destDir}/fonts/`))
          .on('end', () => {
            gulp
              .src(`${srcDir}/fonts/${file}`)
              .pipe(ttf2woff2())
              .pipe(gulp.dest(`${destDir}/fonts/`))
              .on('end', resolve)
              .on('error', reject);
          })
          .on('error', reject);
      });
    }

    // Генерація CSS
    generateFontsCSS(destDir, srcDir);
    console.log('✅ Шрифти сконвертовано');

    browserSync.reload();
  };
};

function generateFontsCSS(destDir, srcDir) {
  const fontsDir = path.join(destDir, 'fonts');
  const cssFile = path.join(srcDir, 'scss/base/_fontsAutoGen.scss');

  if (!fs.existsSync(fontsDir)) return;

  const fonts = fs.readdirSync(fontsDir);
  const fontFiles = fonts.filter(f => f.endsWith('.woff2'));

  if (fontFiles.length === 0) return;

  let cssContent = '// Автоматично згенерований файл. Не редагувати!\n\n';
  const processed = new Set();

  fontFiles.forEach(file => {
    const name = path.basename(file, '.woff2');
    if (processed.has(name)) return;

    processed.add(name);
    const parts = name.split('-');
    const family = parts[0] || name;
    let weight = parts[1] || 'regular';

    const fontWeight = mapWeight(weight);

    cssContent += `@font-face {\n`;
    cssContent += `\tfont-family: '${family}';\n`;
    cssContent += `\tfont-display: swap;\n`;
    cssContent += `\tsrc: url("../fonts/${name}.woff2") format("woff2"), url("../fonts/${name}.woff") format("woff");\n`;
    cssContent += `\tfont-weight: ${fontWeight};\n`;
    cssContent += `\tfont-style: normal;\n`;
    cssContent += `}\n\n`;
  });

  fs.writeFileSync(cssFile, cssContent);
  console.log(`✅ CSS файл створено: ${cssFile}`);
}

function mapWeight(weight) {
  const map = {
    thin: 100,
    light: 300,
    regular: 400,
    medium: 500,
    semibold: 600,
    bold: 700,
    extrabold: 800,
    black: 900,
  };
  return map[weight?.toLowerCase()] || 400;
}
