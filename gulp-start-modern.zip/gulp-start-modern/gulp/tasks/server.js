const browserSync = require('browser-sync').create();

module.exports = (dir, port) => {
  return function server(done) {
    browserSync.init({
      server: {
        baseDir: `./${dir}/`,
        index: 'index.html',
      },
      port: port,
      open: true,
      notify: true,
      ui: false,
      reloadOnRestart: true,
      reloadDelay: 500, // ← збільшено затримку
      reloadDebounce: 0,
      injectChanges: true,
      ghostMode: false,
      // Явно вказуємо файли для відстеження
      files: [
        `./${dir}/**/*.html`,
        `./${dir}/css/**/*.css`,
        `./${dir}/js/**/*.js`,
      ],
      // Налаштування для інжекта скрипта
      snippetOptions: {
        rule: {
          match: /<\/body>/i,
          fn: function (snippet, match) {
            return snippet + match;
          },
        },
      },
    });

    // Додаємо додатковий watcher через BrowserSync
    browserSync.watch(`./${dir}/**/*.*`).on('change', browserSync.reload);

    done();
  };
};
