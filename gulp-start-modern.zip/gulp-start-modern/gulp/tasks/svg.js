const gulp = require('gulp');
const svgsprite = require('gulp-svg-sprite');
const plumber = require('gulp-plumber');
const notify = require('gulp-notify');
const browserSync = require('browser-sync').create();
const config = require('../config');

module.exports = (dir, isProd) => {
  return function svg() {
    return gulp
      .src(config.paths.src.svgIcons)
      .pipe(
        plumber(
          notify.onError({
            title: 'SVG',
            message: 'Error: <%= error.message %>',
          }),
        ),
      )
      .pipe(svgsprite(config.plugins.svgSprite))
      .pipe(gulp.dest(`./${dir}/img/svgsprite/`))
      .pipe(browserSync.reload({ stream: true }));
  };
};
