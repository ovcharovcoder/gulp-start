const gulp = require('gulp');
const sass = require('gulp-sass')(require('sass'));
const sassGlob = require('gulp-sass-glob');
const sourceMaps = require('gulp-sourcemaps');
const replace = require('gulp-replace');
const groupCssMediaQueries = require('gulp-group-css-media-queries');
const autoprefixer = require('gulp-autoprefixer');
const csso = require('gulp-csso');
const plumber = require('gulp-plumber');
const notify = require('gulp-notify');
const browserSync = require('browser-sync');
const config = require('../config');

module.exports = (dir, isProd, sourceMapsEnabled) => {
  return function styles() {
    let stream = gulp.src(config.paths.src.scss).pipe(
      plumber(
        notify.onError({
          title: 'SCSS',
          message: 'Error: <%= error.message %>',
          sound: false,
        }),
      ),
    );

    if (sourceMapsEnabled) {
      stream = stream.pipe(sourceMaps.init());
    }

    stream = stream.pipe(sassGlob()).pipe(
      sass({
        outputStyle: 'expanded',
        silenceDeprecations: ['import', 'legacy-js-api'],
      }).on('error', sass.logError),
    );

    if (isProd) {
      stream = stream
        .pipe(groupCssMediaQueries())
        .pipe(
          autoprefixer({
            grid: true,
            flexbox: true,
            overrideBrowserslist: ['last 5 versions', '> 1%'],
          }),
        )
        .pipe(csso());
    }

    stream = stream.pipe(
      replace(
        /(['"]?)(\.\.\/)+(img|images|fonts|css|scss|sass|js|files|audio|video)(\/[^\/'"]+(\/))?([^'"]*)\1/gi,
        '$1$2$3$4$6$1',
      ),
    );

    if (sourceMapsEnabled) {
      stream = stream.pipe(sourceMaps.write('.'));
    }

    return stream
      .pipe(gulp.dest(`./${dir}/css/`))
      .pipe(browserSync.stream({ match: '**/*.css' }));
  };
};
