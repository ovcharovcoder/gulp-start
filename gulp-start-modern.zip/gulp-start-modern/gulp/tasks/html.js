const gulp = require('gulp');
const fileInclude = require('gulp-file-include');
const replace = require('gulp-replace');
const plumber = require('gulp-plumber');
const notify = require('gulp-notify');
const browserSync = require('browser-sync');
const config = require('../config');

module.exports = (dir, isProd) => {
  return function html(done) {
    return gulp
      .src(config.paths.src.html)
      .pipe(
        plumber(
          notify.onError({
            title: 'HTML',
            message: 'Error: <%= error.message %>',
          }),
        ),
      )
      .pipe(fileInclude(config.plugins.fileInclude))
      .pipe(
        replace(
          /(?<=src=|href=|srcset=)(['"])(\.(\.)?\/)*(img|images|fonts|css|scss|sass|js|files|audio|video)(\/[^\/'"]+(\/))?([^'"]*)\1/gi,
          '$1./$4$5$7$1',
        ),
      )
      .pipe(gulp.dest(`./${dir}/`))
      .on('end', () => {
        // Примусове оновлення
        setTimeout(() => {
          browserSync.reload();
          console.log('🔄 BrowserSync reload triggered');
          done();
        }, 100);
      });
  };
};
