const gulp = require('gulp');
const plumber = require('gulp-plumber');
const notify = require('gulp-notify');
const browserSync = require('browser-sync');
const sharp = require('sharp');
const fs = require('fs').promises;
const path = require('path');
const config = require('../config');

module.exports = (dir, isProd) => {
  return async function images() {
    const srcPath = './src/img/';
    const destPath = `./${dir}/img/`;

    if (!isProd) {
      console.log('🖼️ Конвертація зображень в реальному часі (WebP + AVIF)...');

      try {
        const files = await getAllFiles(srcPath);
        const imageFiles = files.filter(
          file => /\.(jpg|jpeg|png)$/i.test(file) && !file.includes('svgicons'),
        );

        if (imageFiles.length === 0) {
          console.log('⚠️ Немає зображень для конвертації');
          return;
        }

        let converted = 0;

        for (const file of imageFiles) {
          const relativePath = path.relative(srcPath, file);
          const fileName = path.parse(relativePath).name;
          const fileDir = path.dirname(relativePath);

          await fs.mkdir(path.join(destPath, fileDir), { recursive: true });

          if (config.images.webp.enabled) {
            const webpPath = path.join(destPath, fileDir, `${fileName}.webp`);
            await sharp(file)
              .webp({ quality: config.images.webp.quality })
              .toFile(webpPath);
          }

          if (config.images.avif.enabled) {
            const avifPath = path.join(destPath, fileDir, `${fileName}.avif`);
            await sharp(file)
              .avif({ quality: config.images.avif.quality })
              .toFile(avifPath);
          }

          converted++;
        }

        console.log(`✅ Сконвертовано ${converted} зображень у WebP та AVIF`);
        browserSync.reload();
      } catch (error) {
        console.error('❌ Помилка:', error.message);
      }
      return;
    }

    // Продакшен режим
    console.log('🖼️ Оптимізована конвертація зображень...');

    try {
      const files = await getAllFiles(srcPath);
      const imageFiles = files.filter(
        file => /\.(jpg|jpeg|png)$/i.test(file) && !file.includes('svgicons'),
      );

      if (imageFiles.length === 0) {
        console.log('⚠️ Немає зображень для конвертації');
        return;
      }

      let converted = 0;

      for (const file of imageFiles) {
        const relativePath = path.relative(srcPath, file);
        const fileName = path.parse(relativePath).name;
        const fileDir = path.dirname(relativePath);

        await fs.mkdir(path.join(destPath, fileDir), { recursive: true });

        if (config.images.webp.enabled) {
          const webpPath = path.join(destPath, fileDir, `${fileName}.webp`);
          await sharp(file)
            .webp({ quality: config.images.webp.quality })
            .toFile(webpPath);
        }

        if (config.images.avif.enabled) {
          const avifPath = path.join(destPath, fileDir, `${fileName}.avif`);
          await sharp(file)
            .avif({ quality: config.images.avif.quality })
            .toFile(avifPath);
        }

        converted++;
      }

      console.log(`✅ Сконвертовано ${converted} зображень у WebP та AVIF`);
      browserSync.reload();
    } catch (error) {
      console.error('❌ Помилка:', error.message);
    }
  };
};

async function getAllFiles(dir) {
  const files = [];

  try {
    const entries = await fs.readdir(dir, { withFileTypes: true });

    for (const entry of entries) {
      const fullPath = path.join(dir, entry.name);

      if (entry.isDirectory()) {
        if (entry.name !== 'svgicons') {
          files.push(...(await getAllFiles(fullPath)));
        }
      } else if (entry.isFile() && entry.name !== '.DS_Store') {
        files.push(fullPath);
      }
    }
  } catch (error) {
    console.error(`Помилка читання ${dir}:`, error.message);
  }

  return files;
}
