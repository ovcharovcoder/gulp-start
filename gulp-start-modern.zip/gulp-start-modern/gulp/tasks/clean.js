const fs = require('fs');

module.exports = dir => {
  return function clean(done) {
    const dirPath = `./${dir}/`;

    if (fs.existsSync(dirPath)) {
      try {
        fs.rmSync(dirPath, { recursive: true, force: true });
        console.log(`🧹 Очищено: ${dirPath}`);
      } catch (err) {
        console.error(`❌ Помилка очищення:`, err.message);
      }
    }

    done();
  };
};
