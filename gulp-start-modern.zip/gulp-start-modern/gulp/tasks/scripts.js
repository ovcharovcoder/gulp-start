const gulp = require('gulp');
const webpack = require('webpack-stream');
const plumber = require('gulp-plumber');
const notify = require('gulp-notify');
const browserSync = require('browser-sync');
const config = require('../config');

module.exports = (dir, isProd, sourceMapsEnabled) => {
  return function scripts() {
    const webpackConfig = require('../../webpack.config.js');
    const mode = isProd ? 'production' : 'development';

    const webpackConfigWithMode = {
      ...webpackConfig,
      mode: mode,
      devtool: sourceMapsEnabled ? 'source-map' : false,
    };

    return gulp
      .src(config.paths.src.js)
      .pipe(
        plumber(
          notify.onError({
            title: 'JS',
            message: 'Error: <%= error.message %>',
            sound: false,
          }),
        ),
      )
      .pipe(webpack(webpackConfigWithMode))
      .pipe(gulp.dest(`./${dir}/js/`))
      .on('end', () => {
        browserSync.reload();
      });
  };
};
