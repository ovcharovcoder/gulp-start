# 🚀 Оптимізована Gulp збірка для верстки

Сучасна, швидка та зручна збірка для розробки лендінгів та інтернет-магазинів.

## ✨ Можливості

- **Швидкість** - оптимізовані таски без дублювання
- **Сучасні технології** - Webpack 5, Babel 7, Sass
- **Конвертація в реальному часі** - шрифти та зображення конвертуються одразу після додавання
- **Сучасні формати** - WebP, AVIF, WOFF2
- **Зручність** - BrowserSync, source maps, авто-виправлення шляхів
- **Шрифти** - автоматична конвертація OTF/TTF → WOFF/WOFF2 + генерація CSS
- **SVG спрайти** - автоматичне створення спрайтів з SVG іконок
- **Чиста структура** - без зайвих файлів та документації

## 📦 Швидкий старт

```bash
# Встановлення залежностей
npm install

# Режим розробки (з конвертацією в реальному часі)
gulp

# Збірка для продакшену
gulp build
```

```bash
your-project/
├── gulp/                       # Gulp завдання
│   ├── config.js               # Централізовані налаштування
│   ├── tasks/                  # Окремі завдання
│   │   ├── clean.js
│   │   ├── html.js
│   │   ├── styles.js
│   │   ├── scripts.js
│   │   ├── images.js
│   │   ├── svg.js
│   │   ├── fonts.js
│   │   ├── files.js
│   │   └── server.js
│   └── index.js
├── src/                        # Вихідні файли
│   ├── fonts/                  # Шрифти (.otf, .ttf)
│   ├── html/
│   │   ├── base/               # Базові компоненти (шапка, футер)
│   │   │   ├── header.html
│   │   │   └── footer.html
│   │   ├── components/         # Перевикористовувані компоненти
│   │   │   ├── card.html
│   │   │   ├── navigation.html
│   │   │   └── ...
│   │   └── pages/              # Сторінки сайту
│   │       ├── index.html
│   │       ├── about.html
│   │       └── contacts.html
│   ├── img/
│   │   ├── favicons/           # Фавіконки
│   │   ├── svgicons/           # SVG іконки для спрайту
│   │   └── (інші зображення)
│   ├── js/
│   │   ├── modules/            # JS модулі
│   │   └── index.js            # Точка входу
│   ├── scss/
│   │   ├── base/               # Базові стилі
│   │   │   ├── _reset.scss
│   │   │   ├── _vars.scss
│   │   │   ├── _mixins.scss
│   │   │   ├── _fontsAutoGen.scss  # АВТОМАТИЧНО генерується
│   │   │   ├── _base.scss
│   │   │   ├── _containers.scss
│   │   │   └── _utils.scss
│   │   ├── blocks/             # Стилі компонентів
│   │   │   ├── _header.scss
│   │   │   ├── _footer.scss
│   │   │   └── ...
│   │   └── main.scss           # ГОЛОВНИЙ ФАЙЛ (тільки він компілюється)
│   └── files/                  # Інші файли (PDF, ZIP тощо)
├── dist/                       # Готова збірка (авто-генерація)
├── .gitignore
├── gulpfile.js
├── package.json
├── webpack.config.js
└── README.md
```

## 📄 РОБОТА З HTML

Структура папки src/html/

````bash
src/html/
├── base/                       # Базові компоненти
│   ├── header.html             # Шапка (підключається на всіх сторінках)
│   └── footer.html             # Футер (підключається на всіх сторінках)
├── components/                 # Перевикористовувані компоненти
│   ├── card.html               # Картка товару
│   ├── navigation.html         # Навігація
│   ├── breadcrumbs.html        # Хлібні крихти
│   └── ...
└── pages/                      # Сторінки сайту
    ├── index.html              # Головна сторінка
    ├── about.html              # Про нас
    └── contacts.html           # Контакти
    ```
````

## Як створювати сторінки

1. Створіть файл в src/html/pages/ з будь-якою назвою: catalog.html, product.html тощо
2. Підключіть базові компоненти за допомогою @@include()
3. Додавайте контент між шапкою та футером

## Як підключати компоненти

```bash
<!-- В будь-якій сторінці в src/html/pages/ -->
@@include('../base/header.html')

<main class="main">
    <h1>Мій контент</h1>

    <!-- Підключення компонента -->
    @@include('../components/card.html', {
        "title": "Назва товару",
        "price": "1000"
    })
</main>

@@include('../base/footer.html')
```

### Як створити новий компонент

1. Створіть файл src/html/components/my-component.html
2. Напишіть HTML код:

```bash
<div class="my-component">
    <h3>@@title</h3>
    <p>@@text</p>
</div>
```

3. Підключіть в сторінці:

```bash
@@include('../components/my-component.html', {
    "title": "Заголовок",
    "text": "Текст компонента"
})
```

## 🎨 РОБОТА З SCSS

````bash
src/scss/
├── main.scss                 # ГОЛОВНИЙ ФАЙЛ (тільки він компілюється)
├── base/                     # Базові стилі
│   ├── _reset.scss          # Скидання стилів
│   ├── _vars.scss           # Змінні (кольори, шрифти, брейкпоінти)
│   ├── _mixins.scss         # Міксини (адаптив, retina)
│   ├── _fontsAutoGen.scss   # АВТОМАТИЧНО генерується з шрифтів
│   ├── _base.scss           # Базові стилі (body, html)
│   ├── _containers.scss     # Стилі контейнерів
│   └── _utils.scss          # Допоміжні класи
└── blocks/                   # Стилі компонентів
    ├── _header.scss
    ├── _footer.scss
    ├── _card.scss
    └── ...
    ```
````

### Як додати змінні

В src/scss/base/\_vars.scss:

```bash
// Кольори
$primary: #007bff;
$secondary: #6c757d;
$dark: #333;

// Брейкпоінти
$tablet: 992px;
$mobile: 768px;

// Шрифти
$font-main: 'Roboto', sans-serif;
$font-title: 'Montserrat', sans-serif;
```

### Як додати міксини

В src/scss/base/\_mixins.scss:

```bash
// Адаптив
@mixin tablet {
    @media (max-width: 992px) {
        @content;
    }
}

@mixin mobile {
    @media (max-width: 768px) {
        @content;
    }
}

// Retina фони
@mixin mediaBg {
    @media (min-resolution: 144dpi), (min-resolution: 1.5dppx) {
        @content;
    }
}
```

## 🖼️ РОБОТА ІЗ ЗОБРАЖЕННЯМИ

````bash
src/img/
├── favicons/           # Фавіконки
│   ├── favicon.svg
│   └── apple-touch-icon.png
├── svgicons/           # SVG іконки для спрайту (НЕ конвертуються)
│   ├── heart.svg
│   ├── cart.svg
│   └── user.svg
├── products/           # Зображення товарів (конвертуються)
│   ├── product-1.jpg
│   └── product-2.png
└── bg/                 # Фонові зображення (конвертуються)
    └── hero.jpg
    ```
````

## Як додавати зображення

```bash
Тип	            Куди класти	                   Що відбувається
Звичайні        фото	                       src/img/ (будь-яка папка)	Конвертуються в WebP + AVIF
Retina          фото	                       src/img/ з суфіксом @2x	Потрібні для якісного відображення
SVG             іконки	                       src/img/svgicons/	Збираються в спрайт (НЕ конвертуються)
Фавіконки	    src/img/favicons/	           Копіюються як є
```

## Як вставляти зображення в HTML

```bash
<!-- Звичайне зображення -->
<img src="./img/products/product-1.jpg" alt="Товар 1">

<!-- Для retina обов'язково мати @2x версію поруч -->
<img src="./img/logo.png" alt="Логотип">

<!-- SVG іконка зі спрайту -->
<svg class="icon icon--heart">
    <use href="./img/svgsprite/sprite.symbol.svg#heart"></use>
</svg>
```

## Як додавати фонові зображення в SCSS

```bash
.my-block {
    // Звичайне фон
    background-image: url('../img/bg/hero.jpg');

    // Retina фон (використовуйте міксин)
    @include mediaBg() {
        background-image: url('../img/bg/hero@2x.jpg');
    }
}
```

## 🔤 РОБОТА З ШРИФТАМИ

Підтримувані формати

```bash
Вхідний          Вихідні
.otf або .ttf    .woff + .woff2
```

## Як додавати шрифти

Покладіть файл шрифту в src/fonts/:

```bash
src/fonts/
├── Roboto-Regular.ttf
├── Roboto-Bold.otf
└── Roboto-Light.ttf
```

Запустіть збірку (конвертація відбудеться автоматично): gulp
Файл \_fontsAutoGen.scss згенерується АВТОМАТИЧНО в src/scss/base/

## Як використовувати шрифти в SCSS

Файл \_fontsAutoGen.scss згенерується автоматично:

```bash
@font-face {
    font-family: 'Roboto';
    font-display: swap;
    src: url("../fonts/Roboto-Regular.woff2") format("woff2"),
         url("../fonts/Roboto-Regular.woff") format("woff");
    font-weight: 400;
    font-style: normal;
}
```

Використання в стилях:

```bash
body {
    font-family: 'Roboto', sans-serif;
    font-weight: 400;
}

h1 {
    font-family: 'Roboto', sans-serif;
    font-weight: 700;
}
```

## Правила іменування шрифтів

```bash
Назва-Вага.otf

Наприклад:
Roboto-Regular.otf      →   font-weight: 400
Roboto-Bold.otf         →   font-weight: 700
Roboto-Light.otf        →   font-weight: 300
Montserrat-Medium.otf   →   font-weight: 500
```

## 📜 РОБОТА З JAVASCRIPT

```bash
src/js/
├── index.js           # Головний файл (точка входу)
├── modules/           # Модулі
│   ├── mobile-nav.js
│   ├── slider.js
│   └── form.js
└── libs/              # Сторонні бібліотеки (опціонально)
```

## Як створити новий модуль

src/js/modules/my-module.js:

```bash
function myModule() {
    console.log('Модуль працює');

    const button = document.querySelector('.my-button');
    if (button) {
        button.addEventListener('click', () => {
            alert('Clicked!');
        });
    }
}

export default myModule;
```

## Як підключити модуль

src/js/index.js:

```bash
import mobileNav from './modules/mobile-nav.js';
import myModule from './modules/my-module.js';

// Ініціалізація
document.addEventListener('DOMContentLoaded', () => {
    mobileNav();
    myModule();
});
```

## Як додати бібліотеку через npm

```bash
# Встановіть бібліотеку
npm install swiper --save
```

src/js/index.js:

```bash
import Swiper from 'swiper';
import 'swiper/css/swiper.css';

document.addEventListener('DOMContentLoaded', () => {
    const swiper = new Swiper('.swiper', {
        loop: true,
        navigation: true,
    });
});
```

## ⚡ КОРОТКИЙ ЧЕК-ЛИСТ

Початок роботи:

- npm install
- gulp

## Створення нової сторінки

1. Додати src/html/pages/page-name.html
2. Підключити @@include('../base/header.html')
3. Підключити @@include('../base/footer.html')

## Додавання стилів

1. Створити src/scss/blocks/\_component.scss
2. Написати стилі
3. Використати міксини @include tablet(), @include mobile()

## Додавання зображень

1. Покласти JPG/PNG в src/img/ (будь-яка папка)
2. Для retina: додати @2x версію
3. Для SVG іконок: покласти в src/img/svgicons/

## Додавання шрифтів

1. Покласти .otf або .ttf в src/fonts/
2. Запустити gulp (конвертація автоматична)

## Додавання JS

1. Створити модуль в src/js/modules/
2. Імпортувати в src/js/index.js
3. Ініціалізувати функцію

## Завершення проекту

1. gulp build (збірка продакшен версії)
2. Перевірити dist/ папку
3. Завантажити на хостинг

## 🎯 ОСНОВНІ КОМАНДИ

```bash
Команда        Опис
npm install    Встановлення залежностей
gulp           Запуск режиму розробки
gulp build     Збірка продакшен версії
```
