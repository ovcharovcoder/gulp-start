function mobileNav() {
  const navBtn = document.querySelector('.mobile-nav-btn');
  const mobileNav = document.querySelector('.mobile-nav');
  const navIcon = document.querySelector('.nav-icon');
  const body = document.body;

  if (!navBtn || !mobileNav) return;

  navBtn.addEventListener('click', e => {
    e.stopPropagation();
    mobileNav.classList.toggle('mobile-nav--open');
    navIcon.classList.toggle('nav-icon--active');
    navBtn.classList.toggle('active');
    body.classList.toggle('no-scroll');
  });

  // Закриття при кліку на посилання
  const navLinks = mobileNav.querySelectorAll('.mobile-nav__link');
  navLinks.forEach(link => {
    link.addEventListener('click', () => {
      mobileNav.classList.remove('mobile-nav--open');
      navIcon.classList.remove('nav-icon--active');
      navBtn.classList.remove('active');
      body.classList.remove('no-scroll');
    });
  });

  // Закриття при кліку на фон
  mobileNav.addEventListener('click', e => {
    if (e.target === mobileNav) {
      mobileNav.classList.remove('mobile-nav--open');
      navIcon.classList.remove('nav-icon--active');
      navBtn.classList.remove('active');
      body.classList.remove('no-scroll');
    }
  });
}

export default mobileNav;
