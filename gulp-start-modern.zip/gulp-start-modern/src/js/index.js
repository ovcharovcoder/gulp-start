import mobileNav from './modules/mobile-nav.js';

document.addEventListener('DOMContentLoaded', () => {
  mobileNav();
  console.log('Сайт готовий до роботи!');
});
