console.log('hello');
console.log(3 + 40);
