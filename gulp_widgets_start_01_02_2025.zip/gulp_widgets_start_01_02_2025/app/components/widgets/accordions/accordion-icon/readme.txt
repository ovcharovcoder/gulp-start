// Accordion template with arrows in the form of SVG icons

// SVG icon code pointing right -- 

// SVG icon code for a black arrow in a circle with a transparent background pointing right
<svg class="arrow" fill="#000000" height="256px" width="256px" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg" transform="rotate(270)"><path d="M256,0C114.618,0,0,114.618,0,256s114.618,256,256,256s256-114.618,256-256S397.382,0,256,0z M256,469.333c-117.818,0-213.333-95.515-213.333-213.333S138.182,42.667,256,42.667S469.333,138.182,469.333,256S373.818,469.333,256,469.333z"/><path d="M347.582,198.248L256,289.83l-91.582-91.582c-8.331-8.331-21.839-8.331-30.17,0c-8.331,8.331-8.331,21.839,0,30.17l106.667,106.667c8.331,8.331,21.839,8.331,30.17,0l106.667-106.667c8.331-8.331,8.331-21.839,0-30.17C369.42,189.917,355.913,189.917,347.582,198.248z"/></svg>

// SVG icon code for a white arrow in a circle with a black background pointing right
<svg class="arrow" fill="#000000" width="256px" height="256px" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg" transform="rotate(270)">
<path d="M256 0C114.837 0 0 114.837 0 256s114.837 256 256 256s256-114.837 256-256S397.163 0 256 0z M377.749 228.416L271.083 335.083c-4.16 4.16-9.621 6.251-15.083 6.251-5.462 0-10.923-2.091-15.083-6.251L134.251 228.416c-8.341-8.341-8.341-21.824 0-30.165s21.824-8.341 30.165 0L256 289.835l91.584-91.584c8.341-8.341 21.824-8.341 30.165 0C386.091 206.592 386.091 220.075 377.749 228.416z"/></svg>


// SVG icon code pointing down -- 

// SVG icon code for a black arrow in a circle with a transparent background pointing down
<svg class="arrow" fill="#000000" height="256px" width="256px" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg"><path d="M256,0C114.618,0,0,114.618,0,256s114.618,256,256,256s256-114.618,256-256S397.382,0,256,0z M256,469.333c-117.818,0-213.333-95.515-213.333-213.333S138.182,42.667,256,42.667S469.333,138.182,469.333,256S373.818,469.333,256,469.333z"/><path d="M347.582,198.248L256,289.83l-91.582-91.582c-8.331-8.331-21.839-8.331-30.17,0c-8.331,8.331-8.331,21.839,0,30.17l106.667,106.667c8.331,8.331,21.839,8.331,30.17,0l106.667-106.667c8.331-8.331,8.331-21.839,0-30.17C369.42,189.917,355.913,189.917,347.582,198.248z"/></svg>

// SVG icon code for a white arrow in a circle with a black background pointing down
<svg class="arrow" fill="#000000" width="800px" height="800px" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
<path d="M256 0C114.837 0 0 114.837 0 256s114.837 256 256 256s256-114.837 256-256S397.163 0 256 0z M377.749 228.416L271.083 335.083c-4.16 4.16-9.621 6.251-15.083 6.251-5.462 0-10.923-2.091-15.083-6.251L134.251 228.416c-8.341-8.341-8.341-21.824 0-30.165s21.824-8.341 30.165 0L256 289.835l91.584-91.584c8.341-8.341 21.824-8.341 30.165 0C386.091 206.592 386.091 220.075 377.749 228.416z"/></svg>

// SVG icon code black cross with transparent background
<svg class="arrow" fill="#000000" width="256px" height="256px" viewBox="0 0 24 24" transform="rotate(45)" xmlns="http://www.w3.org/2000/svg"><path d="M19,19,5,5M19,5,5,19" fill="none" stroke="#000000" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"></path></svg>
