                                              GULP-START + WIDGETS / 01.02.2025
											  

ABOUT THE BUILD
--------------------------------------------------  
Author: Andriy Ovcharov  
Build Date: 01.02.2025  
Description: The "Gulp-start_DatoshCode" build is an auxiliary tool for web developers that enables faster and more convenient website development based on Figma designs. It includes a list of relevant plugins and supports a modular project structure.  

Supported Build Versions:  
Gulp: CLI version: 3.0.0  
Node JS: 22.13.1 (LTS)  

FEATURES OF THE BUILD  
--------------------------------------------------  
- Converts `.scss` files to `.css` with autoprefixer support;  
- Minifies `.css`, `.js`, and image files;  
- Enables live website development with automatic page updates and no caching via BrowserSync;  
- Converts `.png` and `.jpg` images to `.webp`;  
- Optimizes `.svg` files and clears image cache;  
- Converts font files from `.ttf` and `.otf` to `.woff` and `.woff2`, optimizing fonts;  
- Checks `.css` files for errors and compliance with standards using CSS Lint;  
- Supports modular structure and website development using separate components;  
- Contains several widgets for quick site building;
- Displays error notifications during styles and scripts compilation.  

TERMINAL COMMANDS AND SHORTCUTS FOR PROJECT OPERATIONS  
----------------------------------------------------  
1. Commands to install Gulp (if required):  
npm install --global gulp-cli  
npm install --save-dev gulp  

2. Ensure Node.js version 22.13.1 or higher is installed if needed.
The Node.js v22.13.1 installer is available at: https://nodejs.org/dist/v22.13.1/node-v22.13.1-x64.msi

3. Initialize the project: npm i

4. Run Gulp: gulp

5. Stop Gulp:  Ctrl+C

6. Build the final project: gulp build
A dist directory will be created, which can be uploaded to a hosting server.


BUILD STATUS CHECK
---------------------------------------------------
After unpacking the archive contents into the project directory, initialize the build with npm i and run Gulp using gulp.
If a greeting text appears in the browser window, the build is working correctly and is ready to use.


WORKING WITH PROJECT FILES
---------------------------------------------------
 -- Working with Images --
Store all source images in app/images/src. Images will be converted to .webp.
SVG icon images are not converted but compressed instead. Such images should be stored in a separate directory: app/images/icons.
After processing, icon images will be automatically added to app/images/icons.

 -- Working with Fonts --
Store all source fonts in .ttf and .otf formats in app/fonts/src. They will be converted to .woff and .woff2 formats and moved to app/fonts.
To ensure successful font conversion, it is recommended to stop Gulp, add fonts to the folder, and restart Gulp. Font conversion may take some time.

 -- Working with CSS Styles --
Most source styles should be written in the _main.scss file located at app/scss.
It is recommended to connect styles of third-party plugins and separate component styles via @use.
The structure of such components should be as follows:

@use 'vars';  // Define variable styles  
@use 'mixins'; // Define mixins  
@use 'optimize';  // Reset CSS  
@use 'anim'; // Define animation styles  
@use 'fonts'; // Define font styles  
@use 'global';  // Define global styles  
@use 'base';  // Define base styles  
@use 'libs';  // Define plugin styles  
@use 'main'; // Define all styles except global and base  
@use 'media';   // Define responsive styles  

 -- Working with JavaScript --
Write source scripts in corresponding files located in app/js.
Scripts of plugins installed via npm should be specified in gulpfile.js.

 -- Working with HTML Pages --
Store all HTML pages in app/pages, and separate components (e.g., header.html, sidebar.html, footer.html) should be stored in app/components.
Include them in HTML pages using @@include.

Example:

@@include('header.html')  
... page content ...  
@@include('footer.html')  

Installing a Plugin:
To install a new plugin, run the following command in the terminal:

npm i "package-name" -D  

Example:

npm i swiper -D  

The new package will be installed in the node_modules folder.
To connect plugin scripts, navigate to the "Scripts and return src([...])" section in gulpfile.js and specify the path to the plugin's non-minified .js file.

Example with the "swiper" plugin:

// Scripts  
function scripts() {  
  return src([  
    "node_modules/swiper/swiper-bundle.js", // Plugin path  
    "app/js/main.js"  
  ])  
  ...  
}  

Include plugin styles via @import in style.scss, preferably in the _libs.scss file, without the .css extension:

@import '../../node_modules/swiper/swiper-bundle';  




ПРО ЗБІРКУ
--------------------------------------------------
Автор: Андрій Овчаров;
Дата збірки: 26.01.2025;
Опис: Збірка "Gulp-start_DatoshCode" є допоміжним інструментом для веброзробника, що дозволяє виконувати розробку вебсайтів за макетами Figma швидше та зручніше, адже має перелік відповідних плагінів та передбачає модульну будову проєкту. 

Збірка підтримує: 
Gulp: CLI version: 3.0.0
Node JS: 22.13.1 (LTS)

ЗБІРКА ДОЗВОЛЯЄ:
-------------------------------------------------
- конвертувати файли стилів .scss у .css з підтримкою автопрефіксерів;
- мініфікувати (стискати) файли .css, .js та файли зображень;
- виконувати розробку вебсайту в live-режимі з автоматичним оновленням сторінок та без кешування завдяки BrowserSync;
- конвертувати файли зображень .png та .jpg у формат .webp;
- оптимізувати файли .svg та виконувати очищення кешу зображень;
- конвертувати файли шрифтів з .ttf та .otf у .woff та .woff2, оптимізувати шрифти;
- перевіряти .css файли на помилки та відповідність стандартам за допомогою CSS Lint;
- підтримує модульну будову, розробку вебсайту з окремих компонентів;
- містить кілька віджетів для швидкої будови сайту;
- показувати повідомлення про помилки під час компіляції стилів та скриптів.


КОМАНДИ ТЕРМІНАЛА ТА КОМБІНАЦІЇ КЛАВІШ ДЛЯ РОБОТИ З ПРОЄКТОМ:
----------------------------------------------------
1. Команди для встановлення gulp (у разі потреби):  
npm install --global gulp-cli
npm install --save-dev gulp

2. Необхідно, у разі потреби, встановити Node.js не менше версії 22.13.1. 
Інсталятор Node.js v.22.13.1 доступний за лінком: https://nodejs.org/dist/v22.13.1/node-v22.13.1-x64.msi

3. Розгорнути стартову збірку на комп'ютері: npm i
4. Запустити gulp: gulp
5. Завершити роботу gulp: Ctrl+C
6. Зібрати остаточний проєкт: gulp build 
Буде створено директорію dist, яку можна додати на хостинг.


ПЕРЕВІРКА РОБОЧОГО СТАНУ ЗБІРКИ:
----------------------------------------------------
Після розпаковки вмісту архіву у теку з проєктом необхідно розгорнути Збірку (команда: npm i) та запустити Gulp (команда: gulp).
Якщо у вікні браузера відобразиться текст привітання, то збірка працює коректно, та її можна використовувати.


РОБОТА З ФАЙЛАМИ ПРОЄКТА
---------------------------------------------------

Робота із зображеннями:
Всі вихідні зображення потрібно зберігати у теці app/images/src. Зображення будуть конвертовані у формат .webp.
Зображення іконок svg не ковертуються, а лише стискаються. Такі зображення необхідно зберігати в окремій теці: app/images/icons. 
Після обробки, зображення іконок буде автоматично додано до теки: app/images/icons.


Робота зі шрифтами:
---------------------------------------------------
Всі вихідні шрифти у форматі .ttf та .otf необхідно зберігати у теці: app/fonts/src. Всі вони будуть конвертовані у формати: woff та woff2 та переміщені до теки: app/fonts. 
Для успішної конвертації шрифтів, бажано зупинити Gulp, додати шрифти до папки та повторно запустити Gulp. Конвертація шрифтів може зайняти деякий час.


Робота зі стилями css:
---------------------------------------------------
Переважна більшість вихідних стилів необхідно прописувати у файлі _main.scss за адресою app/scss, а стилі сторонніх плагінів, а також окремі стилі-компоненти, рекомендується підключати через @use.
При цьому структура таких компонентів має наступний вигляд:

@use 'vars';  // Вказуються стилі змінних
@use 'mixins'; // Вказуються міксини
@use 'optimize';  // reset css
@use 'anim'; // Вказуються стилі для анімації
@use 'fonts'; // Вказуються стилі для шрифтів
@use 'global';  // Вказуються глобальні стилі
@use 'base';  // Вказуються базові стилі
@use 'libs';  // Вказуються стилі до плагінів
@use 'main'; // Вказуються всі стилі окрім глобальних та базових
@use 'media';   // Вказуються стилі для адаптиву



Робота зі скриптами javascript:
----------------------------------------------------
Усі вихідні скрипти бажано прописувати у відповідні файли за адресою app/js. Скрипти плагінів, встановлені через npm, необхідно прописувати gulpfile.js.


Робота зі сторінками html:
----------------------------------------------------
Всі сторінки html слід зберігати за адресою: app/pages, а окремі їх компоненти (header.html, sidebar.html, footer.html та ін.) рекомендується зберігати за адресою: app/components і під'єднувати до html-сторінок, через @@include.

Наприклад: 

@@include('header.html') - під'єднуємо header.html

... код сторінки ...

@@include('footer.html') - під'єднуємо footer.html


Установка плагіна до Збірки:
---------------------------------------------------
Для встановлення нового плагіна варто ввести команду в термінал:
npm i "назва пакета" -D

Наприклад:
npm i swiper -D

Новий пакет встановлюється в папку "node_modules".

Для підключення скриптів плагіну необхідно у файлі gulpfile.js перейти до розділу "Scripts і return src([...])" та на самому початку прописати шлях до файлу js плагіна (не мініфікований). 

Приклад з плагіном "swiper".

// Scripts
function scripts() {
   return src([
     "node_modules/swiper/swiper-bundle.js", <-- рядок вказівки шляху до плагіна .js
     "app/js/main.js"
])
...
}

А файли стилів для цього плагіна краще під"єднувати через @import у файлі style.scss, де на початку пишемо:

@import '../../node_modules/swiper/swiper-bundle';

або у файлі "_libs.scss"

без розширення .css!
