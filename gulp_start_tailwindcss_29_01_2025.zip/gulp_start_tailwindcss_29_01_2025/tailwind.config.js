module.exports = {
	content: ['./app/pages/*.html', './app/css/*.css'],
	theme: {
		extend: {
			colors: {},
			fontFamily: {},
		},
	},
	plugins: [],
};
