module.exports = {
	content: ['./app/pages/*.html', './app/css/*.css'],
	theme: {
		extend: {
			colors: {
			 "color-accent": "#FBD784",
			 },
			fontFamily: {
			gilroy: ["Gilroy", "sans-serif"],
			},
		},
	},
	plugins: [],
};
