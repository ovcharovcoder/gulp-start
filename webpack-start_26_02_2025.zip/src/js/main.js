require('../pages/index.html');
require('../style/style.scss');
require('./scripts');
