const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const MiniCssExtractPlugin = require('mini-css-extract-plugin');
const ImageMinimizerPlugin = require('image-minimizer-webpack-plugin');
const CopyWebpackPlugin = require('copy-webpack-plugin');

const mode = process.env.NODE_ENV || 'development';
const devMode = mode === 'development';
const target = devMode ? 'web' : 'browserslist';
const devtool = devMode ? 'source-map' : undefined;

module.exports = {
	mode,
	target,
	devtool,
	devServer: {
		open: true,
		static: {
			directory: path.resolve(__dirname, 'dist'),
		},
	},
	entry: [path.resolve(__dirname, 'src/js', 'main.js')],
	output: {
		path: path.resolve(__dirname, 'dist'),
		clean: true,
		filename: 'js/[name].js',
		assetModuleFilename: 'images/[name][ext]',
	},
	plugins: [
		new HtmlWebpackPlugin({
			template: './src/pages/index.html',
			filename: 'index.html',
		}),
		new MiniCssExtractPlugin({
			filename: 'css/style.css',
		}),
		new CopyWebpackPlugin({
			patterns: [
				{
					from: path.resolve(__dirname, 'src/images/icons'),
					to: path.resolve(__dirname, 'dist/images/icons'),
				},
			],
		}),
	],
	module: {
		rules: [
			{
				test: /\.html$/,
				use: ['html-loader'],
			},
			{
				test: /\.(c|sa|sc)ss$/i,
				use: [
					devMode ? 'style-loader' : MiniCssExtractPlugin.loader,
					'css-loader',
					{
						loader: 'postcss-loader',
						options: {
							postcssOptions: {
								plugins: [require('postcss-preset-env')],
							},
						},
					},
					'sass-loader',
				],
			},
			{
				test: /\.(woff2?|ttf|otf)$/i,
				type: 'asset/resource',
				generator: {
					filename: 'fonts/[name][ext]',
				},
			},
			{
				test: /\.(jpe?g|png|svg)$/i,
				include: path.resolve(__dirname, 'src/images'),
				type: 'asset/resource',
				generator: {
					filename: 'images/[name][ext]',
				},
			},
			{
				test: /\.(?:js|mjs|cjs)$/i,
				exclude: /node_modules/,
				use: {
					loader: 'babel-loader',
					options: {
						presets: [['@babel/preset-env']],
					},
				},
			},
		],
	},
	optimization: {
		splitChunks: {
			chunks: 'all',
		},
		minimizer: [
			new ImageMinimizerPlugin({
				test: /\.(jpe?g|png|svg)$/i,
				include: path.resolve(__dirname, 'src/images'),
				minimizer: {
					implementation: ImageMinimizerPlugin.imageminGenerate,
					options: {
						plugins: [
							['imagemin-mozjpeg', { quality: 75 }],
							['imagemin-pngquant', { quality: [0.65, 0.9] }],
							['imagemin-webp', { quality: 75 }],
							['imagemin-svgo', { quality: 75 }],
						],
					},
				},
			}),
		],
	},
};
